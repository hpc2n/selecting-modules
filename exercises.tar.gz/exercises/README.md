# Exercises

Some of the exercises can be found in the text of the presentations. Those have also been gathered here for ease. 

These are the sections and folders: 
1. The module system
2. Module system commands 
3. Compiler toolchains
4. Software module examples
5. Modules in batch scripts

