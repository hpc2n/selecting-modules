# Exercises

Most of the exercises can be found in the text of the presentations, so they are mostly just gathered here for ease. 

These are the sections and folders: 
1. The module system - overview
2. The module system - commands 
3. Compiler toolchains
4. Software module examples
5. Modules in batch scripts

