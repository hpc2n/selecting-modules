# Exercises for the compiler toolchains section  

1. Check if the compiler toolchain ``foss`` is available at your centre
2. Check if the compiler toolchain ``intel`` is available at your centre
3. Pick one of the versions of either ``foss`` or ``intel`` and load it. Then do ``module list``. What got loaded? Was it more than you expected? 

